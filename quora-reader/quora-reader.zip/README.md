## Quora Reader

Removed header of Quora website and minimalize the webpage itself